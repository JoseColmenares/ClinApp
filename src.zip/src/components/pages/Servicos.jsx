import React from 'react';

const Servicos = () => (
  <div className="pagina-base">
    <h2>Serviços</h2>
    <p>Em desenvolvimento por Saka</p>
  </div>
);

export default Servicos;
