import React from 'react';

const Medicos = () => (
  <div className="pagina-base">
    <h2>Médicos</h2>
    <p>Em desenvolvimento por Saka</p>
  </div>
);

export default Medicos;
